package com.firebow.event;

import com.firebow.util.*;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class FireBowRuntime {

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    // Entity ID dedup
    private final Map<Integer, Long> acceptedArrows = new ConcurrentHashMap<>();
    private static final long ARROW_DEDUP_WINDOW_MS = 3000L;

    // Pending carts — đặt trong beforeSync thay vì onClientTick
    // Key: pos, Value: [ticksLeft, retryCount, syncReady]
    // syncReady=1 nghĩa là đã sẵn sàng đặt ngay khi beforeSync được gọi
    private final Map<BlockPos, int[]> pendingCarts = new ConcurrentHashMap<>();
    private static final int MAX_CART_RETRIES = 8;

    private final TickSynchronizer tickSync = new TickSynchronizer();
    private volatile boolean enabled = true;

    private FireBowRuntime() {}

    public boolean isEnabled()           { return enabled; }
    public void    toggle()              { enabled = !enabled; }

    public boolean isDuplicateArrow(int entityId) {
        Long lastMs = acceptedArrows.get(entityId);
        return lastMs != null &&
            (System.currentTimeMillis() - lastMs) < ARROW_DEDUP_WINDOW_MS;
    }

    public void acceptArrow(int entityId, BlockPos railPos, int tickDelay) {
        acceptedArrows.put(entityId, System.currentTimeMillis());
        AsyncRunner.runDelayed(() -> acceptedArrows.remove(entityId), ARROW_DEDUP_WINDOW_MS);
        // syncReady=0 khi mới tạo, đếm ngược từ tickDelay
        pendingCarts.put(railPos, new int[]{ tickDelay, 0, 0 });
    }

    /**
     * Gọi từ ClientTickMixin — đếm ngược tick.
     * Khi tick về 0 thì đánh dấu syncReady=1 để beforeSync xử lý.
     */
    public void onClientTick(MinecraftClient client) {
        tickSync.onClientTick();
        if (pendingCarts.isEmpty()) return;

        for (int[] state : pendingCarts.values()) {
            if (state[2] == 1) continue; // đã ready, chờ beforeSync
            state[0]--;
            if (state[0] <= 0) state[2] = 1; // đánh dấu ready
        }
    }

    /**
     * Học từ BOOST-FPS beforeSync pattern:
     * Gọi ngay TRƯỚC sendMovementPackets — đảm bảo interact packet
     * đi cùng movement packet, bypass Grim/Vulcan timing check.
     */
    public void beforeSync() {
        if (!enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        Iterator<Map.Entry<BlockPos, int[]>> iter = pendingCarts.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<BlockPos, int[]> entry = iter.next();
            BlockPos pos  = entry.getKey();
            int[] state   = entry.getValue();

            // Chỉ xử lý những cái đã ready
            if (state[2] != 1) continue;

            boolean hasRail =
                mc.world.getBlockState(pos).isOf(Blocks.RAIL) ||
                mc.world.getBlockState(pos).isOf(Blocks.POWERED_RAIL);

            if (!hasRail) {
                if (state[1] < MAX_CART_RETRIES) {
                    // Retry: reset về đếm ngược 1 tick
                    state[0] = 1;
                    state[1]++;
                    state[2] = 0;
                } else {
                    iter.remove();
                }
                continue;
            }

            iter.remove();

            // Đặt cart — cùng lúc với movement packet (anti-cheat safe)
            SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
            if (!cart.isMissing()) {
                int saved = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = cart.slot;
                InteractionUtil.placeOnTop(mc, pos);
                mc.player.getInventory().selectedSlot = saved;
            }
        }
    }
}
